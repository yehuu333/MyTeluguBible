# My Telugu Bible (starter project)

A lightweight Android Bible reader/search app project. It is built in GitHub Actions, so you do not need to install Android Studio on your phone.

## Included features
- Telugu Bible reading by book and chapter
- Search all included verses for exact text or substring matches
- Displays every matching verse in the included text (scrollable results; no app-imposed result cap)
- Works offline because the Bible JSON files are bundled into the APK during cloud build
- Bookmarks stored on the device

## Bible text source
Build workflow downloads `aruljohn/Bible-telugu` from GitHub and includes its JSON files. That repository lists all 66 books and has an MIT license file. Check the source repository and its licence before redistributing builds: https://github.com/aruljohn/Bible-telugu

## Build using only your phone
1. Download and extract this ZIP on your phone.
2. Sign in to GitHub or create an account at https://github.com.
3. Create a **public** repository named `MyTeluguBible`.
4. Upload the extracted project files/folders to the repository (not the ZIP itself). Keep `.github/workflows/build.yml` in place.
5. Open the repository's **Actions** tab and enable workflows if prompted.
6. Open **Actions → Build Android APK → Run workflow** (or push/commit any change to start it).
7. Wait for the green check mark. Open the completed run and download the artifact named `MyTeluguBible-debug-apk`.
8. Extract the artifact ZIP, then tap the APK to install. Android may ask you to allow your browser/file manager to install unknown apps.

## Important
This is a starter project, not a prebuilt or tested APK. The cloud build must succeed first. The Bible text source may contain spacing/orthography inconsistencies, and substring matching cannot infer every grammatical root or synonym. It searches all verses in the bundled text and includes longer words containing the search string.
